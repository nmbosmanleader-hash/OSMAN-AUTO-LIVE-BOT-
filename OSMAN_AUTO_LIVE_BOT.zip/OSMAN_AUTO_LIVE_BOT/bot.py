import logging
import secrets
import sqlite3
from datetime import datetime, timezone

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler, MessageHandler,
    ContextTypes, filters
)
from config import BOT_TOKEN, ADMIN_IDS, CHANNEL_ID

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s: %(message)s"
)
DB = "osman_live_bot.db"


def db():
    return sqlite3.connect(DB)


def init_db():
    with db() as con:
        con.execute("""CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            username TEXT,
            first_name TEXT,
            approved INTEGER DEFAULT 0,
            joined_at TEXT
        )""")
        con.execute("""CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT
        )""")
        con.execute("""CREATE TABLE IF NOT EXISTS access_keys (
            key TEXT PRIMARY KEY,
            uses_left INTEGER DEFAULT 1,
            active INTEGER DEFAULT 1
        )""")


def setting(key, default=""):
    with db() as con:
        row = con.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    return row[0] if row else default


def set_setting(key, value):
    with db() as con:
        con.execute(
            "INSERT INTO settings(key,value) VALUES(?,?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, str(value))
        )


def is_admin(user_id):
    return user_id in ADMIN_IDS


def is_approved(user_id):
    if is_admin(user_id):
        return True
    with db() as con:
        row = con.execute("SELECT approved FROM users WHERE user_id=?", (user_id,)).fetchone()
    return bool(row and row[0])


def main_keyboard():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🔴 JOIN LIVE", callback_data="join_live")],
        [InlineKeyboardButton("🔑 ENTER ACCESS KEY", callback_data="enter_key")],
        [InlineKeyboardButton("📢 JOIN CHANNEL", url=setting("channel_url", "https://t.me/"))],
        [InlineKeyboardButton("📱 MY ACCOUNT", callback_data="my_account"),
         InlineKeyboardButton("💫 LIVE STATUS", callback_data="live_status")],
        [InlineKeyboardButton("📩 REQUEST TO OWNER", callback_data="owner")]
    ])


def admin_keyboard():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📊 LIVE STATUS", callback_data="live_status")],
        [InlineKeyboardButton("🔴 SET LIVE", callback_data="admin_setlive"),
         InlineKeyboardButton("⏹ END LIVE", callback_data="admin_endlive")],
        [InlineKeyboardButton("🔑 CREATE ACCESS KEY", callback_data="admin_key")],
        [InlineKeyboardButton("👥 USERS", callback_data="admin_users")],
        [InlineKeyboardButton("📢 SEND ANNOUNCEMENT", callback_data="admin_broadcast")]
    ])


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    u = update.effective_user
    with db() as con:
        con.execute(
            """INSERT INTO users(user_id,username,first_name,joined_at)
            VALUES(?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET
            username=excluded.username, first_name=excluded.first_name""",
            (u.id, u.username or "", u.first_name or "",
             datetime.now(timezone.utc).isoformat())
        )
    msg = (
        "👋 Welcome to OSMAN AUTO LIVE BOT\n\n"
        "Use an access key provided by the owner to unlock live access."
        if not is_approved(u.id) else
        "👋 Welcome back to OSMAN AUTO LIVE BOT."
    )
    await update.message.reply_text(msg, reply_markup=main_keyboard())


async def admin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("⛔ Admin only.")
        return
    await update.message.reply_text("👑 OSMAN ADMIN PANEL", reply_markup=admin_keyboard())


async def status_text():
    active = setting("live_active", "0") == "1"
    return (
        f"📡 LIVE STATUS\n\n"
        f"Status: {'🔴 LIVE' if active else '⚫ OFFLINE'}\n"
        f"Title: {setting('live_title', 'Not set')}\n"
        f"Link: {setting('live_url', 'Not set')}"
    )


async def setlive(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("⛔ Admin only.")
        return
    raw = " ".join(context.args)
    if "|" not in raw:
        await update.message.reply_text(
            "Usage:\n/setlive Live title | https://t.me/your_live_link"
        )
        return
    title, url = [x.strip() for x in raw.split("|", 1)]
    if not title or not url.startswith(("https://", "http://")):
        await update.message.reply_text("Please provide a title and a valid HTTP(S) link.")
        return
    set_setting("live_title", title)
    set_setting("live_url", url)
    set_setting("live_active", "1")
    set_setting("live_started", datetime.now(timezone.utc).isoformat())
    await update.message.reply_text("✅ Live details saved.\n\n" + await status_text())
    if CHANNEL_ID:
        try:
            await context.bot.send_message(
                CHANNEL_ID,
                f"🔴 NOW LIVE\n\n{title}\n\nJoin using the button below.",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("▶ JOIN LIVE", url=url)]
                ])
            )
        except Exception:
            logging.exception("Could not post live announcement to channel")


async def endlive(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("⛔ Admin only.")
        return
    set_setting("live_active", "0")
    await update.message.reply_text("⏹ Live marked as ended.")


async def key_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("⛔ Admin only.")
        return
    uses = 1
    if context.args:
        try:
            uses = max(1, min(1000, int(context.args[0])))
        except ValueError:
            await update.message.reply_text("Usage: /newkey [number_of_uses]")
            return
    key = secrets.token_urlsafe(8)
    with db() as con:
        con.execute("INSERT INTO access_keys(key,uses_left) VALUES(?,?)", (key, uses))
    await update.message.reply_text(f"🔑 New access key:\n`{key}`\nUses: {uses}", parse_mode="Markdown")


async def users_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("⛔ Admin only.")
        return
    with db() as con:
        rows = con.execute(
            "SELECT user_id,username,approved FROM users ORDER BY joined_at DESC LIMIT 50"
        ).fetchall()
    if not rows:
        await update.message.reply_text("No users yet.")
        return
    lines = ["👥 USERS (latest 50)"]
    for uid, username, approved in rows:
        lines.append(f"{uid} | @{username or 'no_username'} | {'approved' if approved else 'pending'}")
    await update.message.reply_text("\n".join(lines))


async def callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    uid = q.from_user.id
    data = q.data
    await q.answer()

    if data == "enter_key":
        context.user_data["awaiting_key"] = True
        await q.message.reply_text("Send your access key in a message.")
    elif data == "join_live":
        if not is_approved(uid):
            await q.message.reply_text("🔒 Access locked. Enter an access key first.")
            return
        if setting("live_active", "0") != "1":
            await q.message.reply_text("⚫ No live stream is active right now.")
            return
        url = setting("live_url")
        await q.message.reply_text(
            "🔴 Live is available. Tap below to join:",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("▶ JOIN LIVE", url=url)]])
        )
    elif data == "live_status":
        await q.message.reply_text(await status_text())
    elif data == "my_account":
        await q.message.reply_text(
            f"Your Telegram ID: `{uid}`\nAccess: "
            f"{'Approved' if is_approved(uid) else 'Not approved'}",
            parse_mode="Markdown"
        )
    elif data == "owner":
        await q.message.reply_text("Contact the bot owner for access approval.")
    elif data == "admin_setlive":
        if not is_admin(uid): return
        await q.message.reply_text("Use:\n/setlive Live title | https://t.me/live_link")
    elif data == "admin_endlive":
        if not is_admin(uid): return
        set_setting("live_active", "0")
        await q.message.reply_text("⏹ Live marked as ended.")
    elif data == "admin_key":
        if not is_admin(uid): return
        key = secrets.token_urlsafe(8)
        with db() as con:
            con.execute("INSERT INTO access_keys(key,uses_left) VALUES(?,1)", (key,))
        await q.message.reply_text(f"🔑 Access key:\n`{key}`", parse_mode="Markdown")
    elif data == "admin_users":
        if not is_admin(uid): return
        with db() as con:
            count = con.execute("SELECT COUNT(*) FROM users").fetchone()[0]
            approved = con.execute("SELECT COUNT(*) FROM users WHERE approved=1").fetchone()[0]
        await q.message.reply_text(f"👥 Total users: {count}\nApproved: {approved}")
    elif data == "admin_broadcast":
        if not is_admin(uid): return
        context.user_data["awaiting_broadcast"] = True
        await q.message.reply_text("Send the announcement text.")


async def text_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    text = (update.message.text or "").strip()

    if context.user_data.pop("awaiting_key", False):
        with db() as con:
            row = con.execute(
                "SELECT uses_left,active FROM access_keys WHERE key=?", (text,)
            ).fetchone()
            if row and row[0] > 0 and row[1]:
                con.execute("UPDATE users SET approved=1 WHERE user_id=?", (uid,))
                remaining = row[0] - 1
                con.execute(
                    "UPDATE access_keys SET uses_left=?, active=? WHERE key=?",
                    (remaining, 1 if remaining > 0 else 0, text)
                )
                ok = True
            else:
                ok = False
        await update.message.reply_text(
            "✅ Access approved!" if ok else "❌ Invalid, expired, or already-used key.",
            reply_markup=main_keyboard()
        )
        return

    if context.user_data.pop("awaiting_broadcast", False) and is_admin(uid):
        with db() as con:
            ids = [r[0] for r in con.execute("SELECT user_id FROM users").fetchall()]
        sent = 0
        for user_id in ids:
            try:
                await context.bot.send_message(user_id, text)
                sent += 1
            except Exception:
                logging.warning("Broadcast failed for %s", user_id)
        await update.message.reply_text(f"📢 Sent to {sent} users.")
        return


def main():
    if not BOT_TOKEN:
        raise RuntimeError("BOT_TOKEN is missing. Set it in your hosting environment.")
    if not ADMIN_IDS:
        raise RuntimeError("ADMIN_IDS is missing. Set your Telegram numeric user ID.")
    init_db()
    app = Application.builder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("admin", admin))
    app.add_handler(CommandHandler("setlive", setlive))
    app.add_handler(CommandHandler("endlive", endlive))
    app.add_handler(CommandHandler("newkey", key_command))
    app.add_handler(CommandHandler("users", users_command))
    app.add_handler(CallbackQueryHandler(callback))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, text_message))
    print("OSMAN AUTO LIVE BOT is running...")
    app.run_polling()


if __name__ == "__main__":
    main()
