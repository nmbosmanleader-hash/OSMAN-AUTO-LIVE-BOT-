# OSMAN AUTO LIVE BOT

A Telegram bot for managing live-stream announcements, access keys, and approved bot users.

## Important limitation

This bot uses the official Telegram Bot API. It can publish a live link and show a **JOIN LIVE** button to each approved user. It cannot sign in to, control, or automatically join Telegram voice chats using other Telegram user accounts. Each account owner must tap the join link and join themselves.

## Files

- `bot.py` — bot logic and admin/user menus
- `config.py` — environment configuration
- `requirements.txt` — Python dependency
- `.env.example` — example environment variables

## Configure on a Python hosting service

Set these environment variables in your hosting dashboard:

- `BOT_TOKEN`: token from @BotFather
- `ADMIN_IDS`: comma-separated numeric Telegram user IDs (example: `8485932210`)
- `CHANNEL_ID`: optional numeric channel ID, e.g. `-1001234567890`

Install dependencies:

```bash
pip install -r requirements.txt
```

Start command:

```bash
python bot.py
```

Do not upload your real bot token or `.env` file to GitHub.

## Commands

- `/start` — register and show menu
- `/admin` — admin panel
- `/setlive Title | https://t.me/your_live_link` — set live link and announce it
- `/endlive` — mark live as ended
- `/newkey 5` — create a key with 5 uses (default 1)
- `/users` — list recent users

Add the bot as an administrator in your channel with permission to post messages if you want it to publish announcements.

## Database

The bot creates `osman_live_bot.db` automatically. Use persistent storage on your hosting provider so users, keys, and settings survive restarts.
